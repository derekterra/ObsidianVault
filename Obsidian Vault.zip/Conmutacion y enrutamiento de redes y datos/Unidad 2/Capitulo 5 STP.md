# Red redundante
O red altamente tolerante  a fallos, capaza de tener siempre conexion a red, ya que tiene varias formas incapaz de fallar 

## Incovenenientes de la redundancia
Las tramas de ethernet no poseen un tiempo de existenia como los paquetes.....

### Tormentas broadcast
Debido a que el trafico de broadcast se enbia a todos los piertos del switch, todos los si[psotivps cpnectadps deben procesar.]...

### Tramas unicast duplicadas


### Bucles en el armario de cableado

# Protocolo spanning tree (STP)
STP asegura que exista solo una ruta logica entre todos los destinos de la red, al bloquear de formaintencional aquellas rutas redundantes que puedan ocasiconar bucle


# STP compensa fallos
Si detecta que falla un enlace entonces busca otro camino para mandarlas tramas


# Algoritmo STP (STA)
El STA designa un unico switch como puente raiz y lo utiliza como punto de referencia para todos los calculos de rutas

Tofos los switches que comparten STP intercambian tramas de BPDU para determinar el switch que posee el menos IDE de puente (BID) en la red

El switch como el menor BID se transforma en el puente raiz de forma automatica segun los calculos de STA

El BID contiene un valor de prioridad, la direccion MAC del switch emisor y un ID de sistema extendido opcional

Despues de determonar el puente raiz, el STA calcula la ruta mas corta hacia el mismo

Los costos de la ruta se calculan meidante los balores de costo de puerto asociados eon las velovidades de los piestos para cada puerto de switch que atraviesa una ruta determinada

---Examen--- 
**Puestos raiz** Los puertos de switch mas ceranos al puente raiz. Los principales, tiene el menor ID, todos los puertos estan en verde y los que no estan en una contienda para

**Puertos designados** Puertos que no son raices y que un pueden estar enviando trafico (Los que estan en verde)

**Puertos no designados** estan en rojos y esperando que haya una falla para entrar

------ 

# Puente raiz
Cada switch se identifica a si mismo como puente raiz despues del arranque.

A medida que los switches envian sus tramas de BPDU...


# Puente raiz (Basado en prioridad)
El valor predetreminado de la prioridad es 32769 si encuentra a uno con un numero menor, se convertira en el raiz

Los valores pueden incrementar o de decremantar en 4096

# Puente raiz (Basado en direccion MAC)
Toma el menor valor de la mac tomado en HEXADECIMAL

# Comandos 
show spanning-tree 
spanning-tree vlan 1 priority 24576
spanning-tree vlan 1 root primary
spanning-tree vlan 1 root secundary

## Configurar prioridad del puerto

int fa0/2
spanning-tree port-priority 112 

## Tecnolofia PortFast de Cisco
### Que es PortFast?
No pasar por los diretentes estados, ponerlo de forma activa directamente

### Habilitar PortFast
Interface FastEthernet 0/11
spanning tree portgast

### Deshabilitar PortFast
Interface FastEthernet 0/11
no spanning tree portgast


