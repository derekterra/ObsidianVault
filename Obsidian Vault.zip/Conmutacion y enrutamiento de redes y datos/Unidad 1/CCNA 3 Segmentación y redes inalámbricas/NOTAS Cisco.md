Comand promp es como el CMD
i