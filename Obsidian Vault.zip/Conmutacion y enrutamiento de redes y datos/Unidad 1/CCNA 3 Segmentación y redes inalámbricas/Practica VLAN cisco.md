## 1er paso crear vlan 

![[Pasted image 20220912092731.png]]


## 2do paso asociar puertos


![[Pasted image 20220912093047.png]]

## 3er 


## 4 Enlaces troncales

## 5 Verificar los enlaces troncales esten correctos






9/13/22

##