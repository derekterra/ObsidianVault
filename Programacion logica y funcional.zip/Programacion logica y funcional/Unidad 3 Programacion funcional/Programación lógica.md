# Programación lógica
Los agentes basado en el concimiento funcionan razonando con una representacion del conocimiento sobre el mundo y sus acciones

La lógica proposocional tienen

....



Ejemplo:
Socrates humano
Todos los humanos son mortales
Por lo tanto, socrates es mortal

Como este argumento congtiene nunguna de las coentiva "no" "y"

...


Vamos a ver un lenguaje que ofrece distintas construcciones para reoresentar el conocimiento: lógica de primer orden (LPO)

Supone que existen entidades indviduales(objetos), con caracterisiticas distintivas (propiedades),
entre los que puede haber relaciones de distintios tipos, algunas de llas funciones

Ejemplos de los elementos anteriore:
objetos: gente casas, numeros, colores....
Propiedades: Rojo, redondo, primo..
relaciones: Hermano de, mayor que
funciones: padre de...

Cualquier hecho se refuere a uno o varios de los anteriores elementos, ejemplo
"Si porky, esta en una posicion, las posiciones adyacentes huelen"

De lo anterior podemos distinguir:
Propiedades: Presencia de olor
relaciones: ser adyacentes a 
Funciones: estar en

La popularidad de la LPO se debe a que: 
+ Estructura el mundo en objetos y relaciones lo que facilita el razonamiento
+ Da libertad para describir el mundo de la manera que el diseñador considere apropiado......


# Sistema formal
La especifi..................

## Lenguaje:
Este elemento esta asociado a la sintaxis de la logica de primer orden y de los programas logicos.
El lenguaje de un sistema formal esta dado por un conjutno de simbolos conocido como alfabeto y una serie de reglas de construccion o sintacticas. Una expresion es  ..............

## Teoria de modelo

## Teoria de prueba
Tenemos nuestras formulas y tenemos que relacionarlas para encontrar cosas nuevas

# Sintaxis y semantica de la LPO
En la LPO existen sentencias representando hechos y terminos representando objetos
Los simbolos que se usan son los sobilos de constante, predicado y funcion, las variables las conectivas logicas, los cuantificadores, la igualdad y los parentesis

Ejemplo:
Simbolos de constente: ReyJuan, 2, UJI,...
Simbolos de predicado: Redondo, hermano,>,...
Simbolos de funcion: Coseno, padre, pernaIzquierdaDe,...


..............


## La semantica de los sibolos constantes
Especifica a que objeto se refieren siguiendo las pautas:
+ Una constante se refiere aun solo objeto
+ Puede haber dos contantes haciendo referencia al mismo objeto
+ No es ecesario nombar todos los objetos del universo
## La smeantica de los sibolos de predicado
Especifica a que relacion hacen referencia

Formalmente toda relacion se define mediante el conjunto de tuplas que la satisfacen, p.e. la relacion de hermandad:
{(Rey Juan, Ricardo Corazón de León), (Ricardo Corazón de León, Rey Juan)}

hermanode(Rey Juan, Ricardo corazon de leon)
hermanode(Ricardo corazon de leon, Rey Juan)

##

## La sintaxis de los terminos
Los simbolos de constante son terminos
Un subolo de funcion seguido de una lista entre parentesis de terminos(argumentos) es un termino, ejemplo:

##

## La sintaxis de las sentencias atómicas

## La semantica de las sentencias atomicas

## La sintaxis de las sentencias compuestas

## La semantica de sentencias compuestas

Es similar a la de las entencias con conectivas de la lógica proposicional

## La semantica de sentencias con cuantificadores


,a A inversa significa que para cada "variable" hay una "varuabke"


## La smeantica de sentencia con la igualdad